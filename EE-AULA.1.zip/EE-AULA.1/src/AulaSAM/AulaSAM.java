package AulaSAM;

public class AulaSAM {

    public static void AulaSAM(String[]arge){

        System.out.println("Hello world!");

    }

}
